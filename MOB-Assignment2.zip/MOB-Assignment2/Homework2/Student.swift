//
//  Student.swift
//  Homework2
//
//  Created by Kannan Chandrasegaran on 25/6/15.
//  Copyright (c) 2015 Kannan Chandrasegaran. All rights reserved.
//

import Foundation

class Student {
  var firstName:String = "defaultfirst"
  var lastName:String = "defaultlast"
  var age:Int = 0
  var scores:[Int] = []
  var phoneNumber:Int?
  var profilePicURL:String = ""
}